package Entities;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MessageTest {

    @Test
    void getSender() {
    }

    @Test
    void getRecepient() {
    }

    @Test
    void getContent() {
    }
}