package Entities;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    @Test
    void getName() {
    }

    @Test
    void getPassword() {
    }

    @Test
    void getPersonalSchedule() {
    }

    @Test
    void getFriendList() {
    }

    @Test
    void setName() {
    }

    @Test
    void setPassword() {
    }

    @Test
    void getId() {
    }
}