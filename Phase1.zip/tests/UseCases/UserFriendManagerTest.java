package UseCases;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserFriendManagerTest {

    @Test
    void messagable() {
    }

    @Test
    void checkHistoryMessage() {
    }

    @Test
    void sendMessageTo() {
    }

    @Test
    void addNewFriend() {
    }

    @Test
    void removeFromFriendList() {
    }
}