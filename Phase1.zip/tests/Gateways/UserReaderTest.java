package Gateways;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserReaderTest {

    @Test
    void readFile() {
    }

    @Test
    void saveFile() {
    }
}