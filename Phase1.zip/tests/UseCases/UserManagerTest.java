package UseCases;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserManagerTest {

    @Test
    void getCurrentUser() {
    }

    @Test
    void setCurrentUser() {
    }

    @Test
    void getUsers() {
    }

    @Test
    void addUser() {
    }

    @Test
    void attendEvent() {
    }

    @Test
    void leaveEvent() {
    }

    @Test
    void deleteEvent() {
    }

    @Test
    void findUser() {
    }

    @Test
    void changePassword() {
    }
}