package Controllers;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EventMenuControllerTest {

    @Test
    void signUpForEvent() {
    }

    @Test
    void removeSpotFromEvent() {
    }
}