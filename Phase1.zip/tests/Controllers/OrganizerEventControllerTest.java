package Controllers;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrganizerEventControllerTest {

    @Test
    void createEvent() {
    }

    @Test
    void assignSpeaker() {
    }

    @Test
    void removeSpeaker() {
    }

    @Test
    void changeEventDate() {
    }

    @Test
    void changeEventRoom() {
    }

    @Test
    void deleteEvent() {
    }

    @Test
    void eventModifiable() {
    }

    @Test
    void createSpeaker() {
    }
}