package Controllers;

import static org.junit.jupiter.api.Assertions.*;

class SpeakerEventControllerTest {

}