package Entities;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EventTest {

    @Test
    void getEventName() {
    }

    @Test
    void getRoomNumber() {
    }

    @Test
    void getEventTime() {
    }

    @Test
    void setRoomNumber() {
    }

    @Test
    void setEventTime() {
    }

    @Test
    void getAttendees() {
    }

    @Test
    void getOrganizer() {
    }

    @Test
    void hasSpeaker() {
    }

    @Test
    void getSpeaker() {
    }

    @Test
    void setSpeaker() {
    }

    @Test
    void add() {
    }

    @Test
    void remove() {
    }
}