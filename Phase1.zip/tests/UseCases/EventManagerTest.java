package UseCases;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EventManagerTest {

    @Test
    void addAttendee() {
    }

    @Test
    void removeAttendee() {
    }

    @Test
    void removeEvent() {
    }

    @Test
    void getOrganizer() {
    }

    @Test
    void createEvent() {
    }

    @Test
    void getEvents() {
    }

    @Test
    void removeSpeaker() {
    }

    @Test
    void changeDate() {
    }

    @Test
    void findEvent() {
    }

    @Test
    void addUser() {
    }

    @Test
    void removeUser() {
    }

    @Test
    void userCanSignUp() {
    }

    @Test
    void userCanLeave() {
    }

    @Test
    void setSpeaker() {
    }

    @Test
    void hasSpeaker() {
    }

    @Test
    void changeRoom() {
    }
}