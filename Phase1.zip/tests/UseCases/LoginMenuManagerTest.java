package UseCases;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LoginMenuManagerTest {

    @Test
    void password_matches_id() {
    }

    @Test
    void exit() {
    }
}