package Controllers;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserFriendListControllerTest {

    @Test
    void getMessageableList() {
    }

    @Test
    void showChatLog() {
    }

    @Test
    void sendingMessage() {
    }

    @Test
    void removeFrom() {
    }

    @Test
    void add() {
    }

    @Test
    void returnToMenu() {
    }
}