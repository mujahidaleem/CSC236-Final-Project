package UseCases;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SpeakerManagerTest {

    @Test
    void getCurrentSpeaker() {
    }

    @Test
    void getSpeakers() {
    }

    @Test
    void available() {
    }

    @Test
    void dateChangeable() {
    }

    @Test
    void changeDate() {
    }

    @Test
    void setSpeaker() {
    }

    @Test
    void removeEvent() {
    }

    @Test
    void findSpeaker() {
    }
}