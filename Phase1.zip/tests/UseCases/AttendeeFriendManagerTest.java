package UseCases;

import static org.junit.jupiter.api.Assertions.*;

class AttendeeFriendManagerTest {

}