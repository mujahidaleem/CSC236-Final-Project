package UseCases;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrganizerManagerTest {

    @Test
    void getCurrentOrganizer() {
    }

    @Test
    void createSpeaker() {
    }

    @Test
    void cancelEvent() {
    }
}