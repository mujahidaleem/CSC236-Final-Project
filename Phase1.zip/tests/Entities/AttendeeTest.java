package Entities;

import static org.junit.jupiter.api.Assertions.*;

class AttendeeTest {

}