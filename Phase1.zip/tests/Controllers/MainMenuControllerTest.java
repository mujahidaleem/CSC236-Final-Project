package Controllers;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainMenuControllerTest {

    @Test
    void printEventMenu() {
    }

    @Test
    void printMessageMenu() {
    }

    @Test
    void logOut() {
    }

    @Test
    void changePw() {
    }

    @Test
    void sysExit() {
    }
}